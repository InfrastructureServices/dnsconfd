#!/bin/bash

set -e

tempdir=$(mktemp -d)
mkdir "$tempdir"/dnsconfd-1.6.0
cp -r ./* "$tempdir"/dnsconfd-1.6.0
pushd "$tempdir"
tar -czvf "$tempdir"/dnsconfd-1.6.0.tar.gz dnsconfd-1.6.0
popd
mv "$tempdir"/dnsconfd-1.6.0.tar.gz ./distribution
pushd distribution
fedpkg --release=f40 mockbuild
rm -f ./results_dnsconfd/1.6.0/1.fc40/*.src.rpm
mv ./results_dnsconfd/1.6.0/1.fc40/*.rpm ../tests
popd
rm -rf "$tempdir"
